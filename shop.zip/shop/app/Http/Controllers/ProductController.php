<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Str;

use App\Models\Product;

use App\Models\Type;

class ProductController extends Controller
{
    public function index() 
    {
        $data = Product::orderBy('id', 'DESC')->get();
        $title = "Danh sách sản phẩm";
        $main  = "product";
        $staticLink = "/admin/products/";
        return view('admin.board.products.index', compact('staticLink', 'data', 'title', 'main'));
    }

    public function getNew() 
    {
        $data = Type::all();
        $title = "Thêm sản phẩm mới";
        $main  = "product--new";
        return view('admin.board.products.new', compact('data', 'title', 'main'));
    }

    public function postNew(Request $req) 
    {
        $data = new Product;

        $this->validate($req,
            [
                'name' => 'required|unique:products,name|min:10|max:255',
                'content' => 'required|min:50',
                'price' => 'required'

            ], 
            [
                'name.required' => 'Bạn chưa nhập tên sản phẩm.',
                'name.unique' => 'Tên sản phẩm đã tồn tại, vui lòng kiểm tra lại.',
                'name.min' => 'Bạn vui lòng nhập tên sản phẩm ít nhất có độ dài trên 10 ký tự.',
                'name.max' => 'Bạn vui lòng nhập tên sản phẩm nhiều nhất có độ dài dưới 255 ký tự',

                'content.required' => 'Bạn chưa nhập nội dung cho sản phẩm này.',
                'content.min' => 'Bạn vui lòng nhập nội dung cho sản phẩm ít nhất có độ dài trên 50 ký tự.',

                'price.required' => 'Bạn chưa nhập giá tiền cho sản phẩm.'
            ]);
        

            $data->name = $req->name;
            $data->content = $req->content;
            $data->link = Str::slug($data->name, '-');
            $data->price = $req->price;
            $data->bought = 0;

            if($req->hasFile('photos'))
            {
                $file = $req->file('photos');
                $extension = $file->getClientOriginalExtension();
                if($extension != 'png' && $extension != 'jpg' && $extension != 'jpeg')
                {
                    return redirect()->route('NewProduct')->with('message', 'Bạn chỉ được phép upload ảnh có đuôi jpg, png, jpeg');
                }
                $fileName = $file->getClientOriginalName();
                $photos = Str::random(10).'-'.$fileName;

                while(file_exists('upload/products/'.$photos))
                {
                    $photos = Str::random(10).'-'.$fileName;
                }

                $file->move('upload/products/', $photos);

                $data->photos = $photos;
            }
            else
            {
                $data->photos = '';
            }
            $data->stars = 0;
            $data->id_types = $req->types;

            $data->save();


        return redirect()->route('ViewProduct')->with('message', 'Đã thêm sản phẩm thành công.');
    }
}
