@extends('admin.board.layout')

@section('product--new')
    <script src="//cdn.ckeditor.com/4.15.1/standard/ckeditor.js"></script>
    <h1 class="border-bottom p-3 mb-3">
      Thêm sản phẩm mới
    </h1>
        @if(session('message'))
            <div class="alert alert-info">
            {{ session('message') }}
            </div>
        @endif   
        @if(count($errors) > 0)
            <div class="alert alert-warning">
                @foreach ($errors->all() as $error)
                    {{ $error }} <br />                    
                @endforeach
            </div>
        @endif    
      <form method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-group">
            <label for="name">Tên sản phẩm: </label>
            <br />
            <input type="text" class="form-control" name="name" value="" 
            placeholder="Điền tên sản phẩm" />
        </div>
        <div class="form-group">
            <label for="content">Nội dung sản phẩm:</label>
            <br />
            <textarea class="form-control ckeditor" rows="7" name="content"></textarea>
        </div>
        <div class="form-group">
            <label for="photos">Hình ảnh đại diện: </label>
            <br />
            <input type="file" name="photos" accept="image/*" />
        </div>
        <div class="form-group">
            <label for="name">Giá tiền: </label>
            <br />
            <input type="number" class="form-control" name="price" id="price" value="" 
            placeholder="Điền giá sản phẩm" />
        </div>
        <div class="form-group">
            <label for="types">Thư mục:</label>
            <select class="form-control" name="types">
              @foreach ($data as $index=>$item)
                <option value="{{ $item->id }}">{{ $item->name }}</option>
              @endforeach
            </select>
        </div>
          <button type="submit" class="btn btn-lg btn-primary mr-2">Thêm sản phẩm</button>
    </form>
@endsection