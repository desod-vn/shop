<?php $__env->startSection('notification'); ?>

    <h1 class="border-bottom p-3 mb-3">
      Quản lý thông báo
    </h1>
      <?php if(session('message')): ?>
        <div class="alert alert-info">
          <?php echo e(session('message')); ?>

        </div>
      <?php endif; ?>
        <table id="data--table" class="table table-hover table-bordered">
            <thead class="thead-dark">
              <tr>
                <th scope="col">#</th>
                <th scope="col">TT</th>
                <th scope="col">Thông báo</th>
                <th scope="col">Hành động</th>
              </tr>
            </thead>
            <tbody>
                
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($index + 1); ?></th>
                <td class="text-center">
                    <?php if($item->show): ?>
                        <i class="text-success fas fa-eye"></i>
                    <?php else: ?>
                        <i class="fas fa-eye-slash"></i>
                    <?php endif; ?>
                </td>
                <td><?php echo e($item->content); ?></td>
                <td class="d-flex justify-content-between align-items-center">
                    <a href="<?php echo e(asset($staticLink."update/".$item->id)); ?>" class="btn btn-sm btn-primary">Sửa</a>
                    <a href="<?php echo e(asset($staticLink."delete/".$item->id)); ?>" class="btn btn-sm btn-danger">Xóa</a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <a href="<?php echo e(asset($staticLink."new")); ?>" class="btn btn-lg btn-success">Thêm thông báo</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.board.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/shop/resources/views/admin/board/notifications/index.blade.php ENDPATH**/ ?>