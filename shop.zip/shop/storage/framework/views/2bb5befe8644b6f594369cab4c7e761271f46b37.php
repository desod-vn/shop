<?php $__env->startSection('type--delete'); ?>

    <h1 class="border-bottom p-3 mb-3">
        Xóa thư mục: <small><?php echo e($data->name); ?></small>
    </h1>
    <div class="alert alert-info mb-2">
        Bạn có chắc chắn muốn xóa thư mục này. Sau khi xóa mọi bài viết, sản phẩm, thông tin
        thuộc thư mục này cũng sẽ bị xóa.
    </div>
        <a href="<?php echo e(asset($staticLink."delete-sure/".$data->id)); ?>" class="btn btn-lg btn-danger mr-2">Xóa</a>
        <a href="<?php echo e(asset($staticLink)); ?>" class="btn btn-lg btn-primary">Quay lại</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.board.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/shop/resources/views/admin/board/types/delete.blade.php ENDPATH**/ ?>