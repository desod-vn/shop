<?php $__env->startSection('notification--update'); ?>

    <h1 class="border-bottom p-3 mb-3">
        Sửa thông báo
    </h1>
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-warning">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?> <br />                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="content">Sửa nội dung thông báo: </label>
                <br />
                <textarea class="form-control" rows="5" id="content" name="content"><?php echo e($data->content); ?></textarea>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="show" id="show" value="1" checked>
                <label class="form-check-label" for="show">
                Hiện thông báo
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="show" id="hidden" value="0">
                <label class="form-check-label" for="hidden">
                Ẩn thông báo
                </label>
            </div>
            <br />
            <button type="submit" class="btn btn-lg btn-primary mr-2">Sửa thông báo</button>
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.board.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/shop/resources/views/admin/board/notifications/update.blade.php ENDPATH**/ ?>