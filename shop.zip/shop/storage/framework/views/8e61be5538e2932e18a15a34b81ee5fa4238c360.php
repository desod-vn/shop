<?php $__env->startSection('product'); ?>

    <h1 class="border-bottom p-3 mb-3">
      Danh sách sản phẩm
    </h1>
      <?php if(session('message')): ?>
        <div class="alert alert-info">
          <?php echo e(session('message')); ?>

        </div>
      <?php endif; ?>    
        <table id="data--table" class="table table-hover table-bordered">
            <thead class="thead-dark">
              <tr>
                <th scope="col">#</th>
                <th scope="col">Ảnh</th>
                <th scope="col">Tên sản phẩm</th>
                <th scope="col">Nội dung</th>
                <th scope="col">Giá</th>
                <th scope="col">Loại</th>
                <th scope="col">Xem</th>
              </tr>
            </thead>
            <tbody>
                
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <th scope="row"><?php echo e($index + 1); ?></th>
                <td><img src="<?php echo e(asset('upload/products/'.$item->photos)); ?>" alt="" class="img-fluid" /></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e(Str::limit($item->content, 50)); ?>...</td>
                <td><?php echo e($item->price); ?></td>
                <td><?php echo e($item->getType->name); ?></td>
                <td class="d-flex justify-content-center align-items-center">
                    <a href="<?php echo e(asset($item->link)); ?>" class="btn btn-sm btn-info">Xem</a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <a href="<?php echo e(asset($staticLink."new")); ?>" class="btn btn-lg btn-success">Thêm sản phẩm</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.board.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/shop/resources/views/admin/board/products/index.blade.php ENDPATH**/ ?>