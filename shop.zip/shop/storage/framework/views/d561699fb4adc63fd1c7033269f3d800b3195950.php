<?php $__env->startSection('product--new'); ?>
    <script src="//cdn.ckeditor.com/4.15.1/standard/ckeditor.js"></script>
    <h1 class="border-bottom p-3 mb-3">
      Thêm sản phẩm mới
    </h1>
        <?php if(session('message')): ?>
            <div class="alert alert-info">
            <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>   
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-warning">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?> <br />                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>    
      <form method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Tên sản phẩm: </label>
            <br />
            <input type="text" class="form-control" name="name" value="" 
            placeholder="Điền tên sản phẩm" />
        </div>
        <div class="form-group">
            <label for="content">Nội dung sản phẩm:</label>
            <br />
            <textarea class="form-control ckeditor" rows="7" name="content"></textarea>
        </div>
        <div class="form-group">
            <label for="photos">Hình ảnh đại diện: </label>
            <br />
            <input type="file" name="photos" accept="image/*" />
        </div>
        <div class="form-group">
            <label for="name">Giá tiền: </label>
            <br />
            <input type="number" class="form-control" name="price" id="price" value="" 
            placeholder="Điền giá sản phẩm" />
        </div>
        <div class="form-group">
            <label for="types">Thư mục:</label>
            <select class="form-control" name="types">
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
          <button type="submit" class="btn btn-lg btn-primary mr-2">Thêm sản phẩm</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.board.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/shop/resources/views/admin/board/products/new.blade.php ENDPATH**/ ?>